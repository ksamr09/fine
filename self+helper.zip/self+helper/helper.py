# HELPER
# Eric was here
from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from KhieBots.thrift.protocol import TCompactProtocol
from KhieBots.thrift.transport import THttpClient
from KhieBots.ttypes import LoginRequest
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from threading import Thread, activeCount
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
noobcoder = LINE("ericbots59@gmail.com","ssaa1122")
#=======================================================
waitOpen = codecs.open("noobcoder/wait.json","r","utf-8")
settingsOpen = codecs.open("noobcoder/temp.json","r","utf-8")
premiumOpen = codecs.open("noobcoder/user.json","r","utf-8")
javaOpen = codecs.open("noobcoder/java.json","r","utf-8")
#=====================================================================
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
loop = asyncio.get_event_loop()
myAdmin = ["u5bf09e55c0bda7af6a92e3a82c84d037"]
botStart = time.time()
msg_dict = {}
temp_flood = {}
steals = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
premium = json.load(premiumOpen)
java = json.load(javaOpen)

hoho = {
    "savefile": False,
    "namefile": "",
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = { 
    "readMember": {},
    "readPoint": {}
}

wmin = {
    "wMessage": False,
    "textnya": "Enjoying in this group",
}

lvin = {
    "lMessage": False,
    "textnya": "See u next time",
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

setbot = {
    "background": "#000000",
    "text": "#ffffff",
    "separator": "#ffffff"
}

gwcool = {
    "squad": "Eric Bots",
}

javascript = {
    "jskick": "!kickall",
    "jskick1": "!kick1",
    "cancels": "cancel",
}
#=====================================================================
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
#=====================================================================
with open("noobcoder/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("noobcoder/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
def inSteals(from_):
    global steals
    if from_ in steals:
        return True
    return False
def appendSteals(from_):
    try:
        global steals
        if from_ in steals:
            return
        return steals.append(from_)
    except:
        return False
def clearSteals():
    global steals
    steals = []
    return
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "Eric Bots",
            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u708242457e625a5ef306804d8c0b0ac5').pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=u708242457e625a5ef306804d8c0b0ac5"
        }
    }
    sendTemplate(to, data)
def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def helppss(to):
    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Chatbot",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=chatbot"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Feature",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=feature"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Images",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=images"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Profile",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=profile"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Protect",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=protect"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Social",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=social"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Timeline",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=timeline"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Translate",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=translate"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Settings",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=settings"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Banning",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=banning"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Wordban",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=wordban"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Friend",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=friend"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Self",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=self"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Memegen",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=memegen"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Kick",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=kick"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Utility",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=utility"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Github",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=github"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "About",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=about"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Group",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=group"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Mention",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=mention"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Steal",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=steal"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "List",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=list"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Bcast",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=bcast"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Leave",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text="
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Reboot",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=reboot"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Timeleft",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=timeleft"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Logout",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=logout"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }}}]}}
    sendTemplate(to,data)
def foro(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "styles": {
    "footer": {
    "backgroundColor": "{}".format(setbot["background"])
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
     "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    {
    "type": "text",
    "text": text,
    "color": "{}".format(setbot["text"]),
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "md"
    },
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)
def helpss(to):
    ret_ = helpers(to)
    k = len(ret_)//10
    for aa in range(k+1):
        data = {
            "type": "flex",
            "altText": "Help",
            "contents": {
                "type": "carousel",
                "contents": ret_[aa*10 : (aa+1)*10]
            }
        }
        sendTemplate(to, data)
def helpers(to):
    ret_ = []
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Login%20sb"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Restart%20sb"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout%20sb"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Login sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Restart sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Logout sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reader"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Support"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mentions"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Reader',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Support',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Mentions',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    return ret_
def support(to):
    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "khiewuzzheree",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u2cf74acf6ed04d122def4db8ffdd2e39').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('u2cf74acf6ed04d122def4db8ffdd2e39').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~khiewuzzheree"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "welovebigbang",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u6d7732713d9157756ed84fd4bc3191e4').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('u6d7732713d9157756ed84fd4bc3191e4').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~welovebigbang"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "gkada.line",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~gkada.line"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }}]}}
    sendTemplate(to,data)
def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def powpow():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def getmytoken():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def shareall(to, text):
    lol = noobcoder.getGroupIdsJoined()
    for group in lol:
        noobcoder.sendPostToTalk(group, text)
    noobcoder.sendMessage(to, "Share in {} group".format(str(len(lol))))
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
#def Template(to):
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)

def B64e(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64encode(url.encode()).decode())

def B64d(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64decode(url.encode()).decode())
	
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("noobcoderWasHere.mp4")
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
        
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("noobcoder/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def likeNotify(to):
    true = True
    data = {
        "type": "flex",
        "altText": "LIKE NOTIFY",
        "contents": {
            "type": "bubble",
            "styles": {
                "header": {
                    "backgroundColor": "#333333"
                },
                "hero": {
                    "backgroundColor": "#333333"
                },
                "body": {
                    "backgroundColor": "#FFFFFF",
                    "separator": true,
                    "separatorColor": "#FFFFFF"
                },
                "footer": {
                    "backgroundColor": "#333333",
                    "separator": true
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "text",
                        "text": "LIKE NOTIFY",
                        "weight": "bold",
                        "size": "xxl",
                        "color": "#000000",
                        "margin": "md"
                    },
                    {
                        "type": "text",
                        "text": "Your Post Has Been Liked",
                        "size": "xs",
                        "color": "#aaaaaa",
                        "wrap": true
                    },
                    {
                        "type": "separator",
                        "margin": "xxl"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "xxl",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "RENTAL SELFBOT",
                                        "weight": "bold",
                                        "color": "#000000",
                                        "size": "sm",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "PAYMENT :",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• OVO",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "40K",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• T-SEL",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "50K",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• PAYPAL",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "4$",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Get free 100 accounts autolike bots",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "margin":"md"
                            }
                        ]
                    },
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "margin": "md",
                        "contents": [
                            {
                                "type": "text",
                                "text": "Wanna Order ?",
                                "size": "xs",
                                "color": "#000000",
                                "flex": 0
                            }
                        ]
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "md",
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xl"
                            },
                            {
                                "type": "button",
                                "action": {
                                    "type": "uri",
                                    "label": "Click Here",
                                    "uri": "line://ti/p/~justanolep"
                                },
                                "style": "primary",
                                "color": "#000000"
                            }
                        ]
                    }
                ]
            }
        }
    }
    sendTemplate(to, data)
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('noobcoder/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('noobcoder/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('noobcoder/user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = java
        f = codecs.open('noobcoder/java.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
                        
        if op.type in [22,24]:
            client.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
        if op.type == 15:
            print ("[ 15 ] NOTIFIED LEAVE GROUP")
            if lvin["lMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = lvin["textnya"]
                data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Bye bye {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 17:
            print ("[ 17 ] NOTIFIED INVITE INTO GROUP")
            if wmin["wMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = wmin["textnya"]
                data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "Welcome to {}".format(str(fit.name)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 19:
                    khie = noobcoder.getContact(op.param2)
                    ayu = noobcoder.getContact(op.param3)
                    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "#ffffff",
    "contents": [
      {
        "type": "text",
        "text": "KICK NOTIFY",
        "weight": "bold",
        "size": "xxl",
        "margin": "md"
      },
      {
        "type": "separator",
        "color": "#000000"
      },
      {
        "type": "text",
        "text": "Execution :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(khie.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param2).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      },
      {
        "type": "text",
        "text": "Victim :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(ayu.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param3).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            khietag = "u708242457e625a5ef306804d8c0b0ac5"
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 22 and inSteals(sender):
                  if msg.toType == 0:to = sender
                  datah = {
                      "type": "flex",
                      "altText": msg.contentMetadata["ALT_TEXT"],
                      "contents": json.loads(msg.contentMetadata['FLEX_JSON'])
                  }
                  with open("kebotan", "w+") as f:
                    f.write(str(json.dumps(datah, indent=4, sort_keys=True)))
                  noobcoder.sendFile(to, "kebotan", "This ur fvcking file.txt")
                  noobcoder.sendMessage(to, "Not support html content/template, just flex!")
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        noobcoder.sendMessage(to, str(e))
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             noobcoder.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        sendFooter(to,"Profile Image Updated.")
                if msg.contentType == 1: 
                    if settings["changeCoverProfile"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        noobcoder.updateProfileCover(path)
                        sendFooter(to,"Cover Image Updated.")                                           
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
                    if msg._from in myAdmin:
                        if "/remote" in cmd:
                            function = lambda s:s[:1].lower() + s[1:] if s else ''
                            number = cmd.split("/remote:")[1];number = number.split()[0];noobcoder.getGroupIdsJoined()
                            if number.isdigit():number = int(number);group = noobcoder.getGroupIdsJoined()[number-1];to = group
                            cmd = cmd.replace("/remote:%s"%number,"").lstrip().rstrip()
                            if '/remote:' in text:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            else:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            if msg.toType == 0:msg.to = sender
                            elif msg.toType == 2:msg.to = msg.to
                            sendFooter(msg.to, "Command '%s' has been send to : %s" % (cmd, noobcoder.getGroup(group).name))
#==========================================
                    if cmd == "threads":
                        noobcoder.sendMessage(to,'Threads: {}'.format(threading.active_count()))
                        log.info("Debug Threads.")                            
#==========================================
                    elif cmd.startswith("savefile"):
                        if msg._from in myAdmin:
                            text = removeCmd("savefile", text)
                            sep = text.split(" ")
                            key = text.replace(sep[0] + " ", text)
                            if " " in key:
                                noobcoder.sendMessage(to, "Failed !")
                            else:
                                hoho["namafile"] = str(key).lower()
                                hoho["savefile"] = True
                                noobcoder.sendMessage(to, "Send file to save to be「 {} 」".format(str(key).lower()))
                    elif cmd.startswith("exec"):
                        if msg._from in myAdmin:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
#==========================================
                    elif cmd.startswith("down "):
                        if msg._from in myAdmin:
                           number = removeCmd("down", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 5000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 5000.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please specify a valid number.")
                    elif cmd == "الصورة" :
                        if msg._from in myAdmin:
                            settings["changePicture"] = True
                            sendFooter(to, "ارسل الصورة..")
                    elif cmd == "change cover":
                        if msg._from in myAdmin:
                            settings["changeCoverProfile"] = True
                            sendFooter(to,"Send a Image to change cover.")
                    elif cmd == "read on":
                        tailah["siderTemp"][receiver] = []
                        sendFooter(to, "Getreader set to on.")
                    elif cmd == "read off":
                        if receiver in tailah["siderTemp"]:
                            del tailah["siderTemp"][receiver]
                            sendFooter(to, "Getreader set to off.")
                    elif cmd == "welcome on":
                        if wmin["wMessage"] == True:
                            msgs=" 「 Welcome 」\nWelcomemsg already Enable♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to Enable♪"
                            wmin["wMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "welcome off":
                        if wmin["wMessage"] == False:
                            msgs=" 「 wMessage 」\nWelcomemsg already DISABLED♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to DISABLED♪"
                            wmin["wMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd == "leave on":
                        if lvin["lMessage"] == True:
                            msgs=" 「 Leave 」\nLeavemsg already Enable♪"
                        else:
                            msgs=" 「 Leave 」\nLeavemsg set to Enable♪"
                            lvin["lMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "leave off":
                        if lvin["lMessage"] == False:
                            msgs=" 「  Leave 」\nLeavemsg already DISABLED♪"
                        else:
                            msgs=" 「  Leave  」\nLeavemsg set to DISABLED♪"
                            lvin["lMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd.startswith("updatername "):
                        if msg._from in myAdmin:
                            key = removeCmd("updatername", text)
                            kiy = settings["keyCommand"]
                            settings["keyCommand"] = str(key).lower()
                            sendFooter(to, "╭──「 Update Rname 」\n│ ⌬ Status : Success\n│ ⌬ From : "+str(kiy.title())+"\n╰To : "+str(key.title()))
                    elif cmd == "java":
                        if msg._from in myAdmin:               
                            helpz="Java code :\n" 
                            helpz+="\n• Kickall > " + str(javascript['jskick1'])
                            helpz+="\n• Bypass > " + str(javascript['jskick'])
                            helpz+="\n\nSettingsn"
                            helpz+="\n• Change 1 <txt>"
                            helpz+="\n• Change 2 <txt>"
                            noobcoder.sendMessage(to,helpz)
                    elif cmd.startswith("change"):
                        if msg._from in myAdmin:               
           #                 textx = text.replace(text.split(" ")[0]+" ","")
                            textx = removeCmd("change", text)
                            sal = textx.lower()
                            if sal.startswith("1"):
                               texts = textx[2:]
                               javascript["jskick1"] = texts
                               noobcoder.sendMessage(to, "Kickall update to `%s`" % texts)
                            if sal.startswith("2"):
                               texts = textx[2:]
                               javascript["jskick"] = texts
                               noobcoder.sendMessage(to, "Bypass update to `%s`" % texts)
                    elif cmd == javascript['jskick1']:
                        if msg._from in myAdmin:               
                          xyz = noobcoder.getGroup(to)
                          mem = [c.mid for c in xyz.members]
                          targets = []
                          for x in mem:
                            if x not in ["ufaf5a29501b192057f071ee755429177","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targets.append(x)
                          if targets:
                            imkhie = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                            for target in targets:
                              imkhie += ' uid={}'.format(target)
                            success = execute_js(imkhie)
                            if success:noobcoder.sendMessage(to, "Success kick %i members." % len(targets))
                            else:noobcoder.sendMessage(to, "Failed kick %i members." % len(targets))
                          else:noobcoder.sendMessage(to, "Target not found.")
                    elif cmd == javascript['jskick']:
                        if msg._from in myAdmin: 
                          xyz = noobcoder.getGroup(to)
                          if xyz.invitee == None:pends = []
                          else:pends = [c.mid for c in xyz.invitee]
                          targp = []
                          for x in pends:
                            if x not in ["ufaf5a29501b192057f071ee755429177","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targp.append(x)
                          mems = [c.mid for c in xyz.members]
                          targk = []
                          for x in mems:
                            if x not in ["ufaf5a29501b192057f071ee755429177","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targk.append(x)
                          imkhie = 'dual.js gid={} token={}'.format(to, noobcoder.authToken)
                          for x in targp:imkhie += ' uid={}'.format(x)
                          for x in targk:imkhie += ' uik={}'.format(x)
                          execute_js(imkhie)
#==========================================
                    if cmd == "kiss me":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+noobcoder.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")
                    elif cmd == "reader":
                        ret = "Now set : " + str(tailah["siderPesan"])
                        ret += "\n\n⌬ {}read on/off".format(setKey)
                        ret += "\n⌬ {}read set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "leave":
                        ret = "Now set : " + str(lvin["textnya"])
                        ret += "\n\n⌬ {}leave on/off".format(setKey)
                        ret += "\n⌬ {}leave set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "welcome":
                        ret = "Now set : " + str(wmin["textnya"])
                        ret += "\n\n⌬ {}welcome on/off".format(setKey)
                        ret += "\n⌬ {}welcome set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == ".":
                        if msg._from in myAdmin:
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    noobcoder.sendMessage(msg.to, "No invites Pending")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        noobcoder.cancelGroupInvitation(to, [inv])
                                        noobcoder.findAndAddContactsByMid(inv)                                        
                                        noobcoder.inviteIntoGroup(to, [inv])
#==========================================
                    elif cmd.startswith("read set "):
                        text_ = removeCmd("read set", text)
                        try:
                            tailah["siderPesan"] = text_
                            sendFooter(to,"「 Get Reader 」\nChanged to : " + text_)
                        except:
                            foto(to,"「Get Reader 」\nFailed to replace message")
                    elif cmd.startswith("leave set "):
                        text_ = removeCmd("leave set", text)
                        try:
                            lvin["textnya"] = text_
                            sendFooter(to,"「 LeaveMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 LeaveMsg 」\nFailed to replace message")
                    elif cmd.startswith("welcome set "):
                        text_ = removeCmd("welcome set", text)
                        try:
                            wmin["textnya"] = text_
                            sendFooter(to,"「 WelcomeMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 WelcomeMsg 」\nFailed to replace message")
                    elif cmd.startswith("bye "):
                        if msg._from in myAdmin:
                            number = removeCmd("bye", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                noobcoder.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "support":
                        support(to)
                    elif cmd == "تسجيل الدخول" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                 def frzky():
                                     a = powpow()
                                     a.update({'x-lpqs' : '/api/v4/TalkService.do'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     qr = client.getAuthQrcode(keepLoggedIn=1, systemName='noobcoderBot-PC')
                                     link = "line://au/q/" + qr.verifier
                    #              noobcoder.sendMention(to, 'Click link @!, only 2 minutes\n{}'.format(link),"",[msg._from])
                                     contact = noobcoder.getContact(sender)
                                     LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                                     data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "اضغط هنا لتسجيل الدخول",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                            "action": {
                                "type": "uri",
                                "uri": "{}".format(link)
                            }
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                     sendTemplate(to, data)
                                     a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                     json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=a).text)
                                     a.update({'x-lpqs' : '/api/v4p/rs'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     req = LoginRequest()
                                     req.type = 1
                                     req.verifier = qr.verifier
                                     req.e2eeVersion = 1
                                     res = client.loginZ(req)
                                     if msg._from not in premium['listLogin']:
                                         premium['listLogin'][msg._from] =  '%s' % user
                                         isi = "{}".format(res.authToken)
                                         os.system('cp -r login {}'.format(user))
                                         os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                         os.system('screen -dmS {}'.format(user))
                                         os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
										 noobcoder.sendMention(to, "سجل الحساب هنا بالضغط على اسمح line://app/1643727178-0XPGAaRX?type=text&text=",[msg._from])
                                         data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "File : {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "نجح تسجيل الدخول",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                         sendTemplate(to, data)
                                     else:
                                         noobcoder.sendMention(msg.to, '「 طلب الدخول」\n• الحاله : فشل\n• الحساب: @!',' ', [msg._from])
                                 thread = threading.Thread(target=frzky)
                                 thread.daemon = True
                                 thread.start()
                            except:
                                 noobcoder.sendMention(msg.to, '「 طلب الدخول 」\n• الحاله : فشل\n الحساب: @!',' ', [msg._from])
                    elif cmd == "طلب":
                        try:
                            help += "\nالاسم : Eric Helper"
                            help += "\n\nالاوامر الرئيسية :\n"
                            help += "\n⌬ {}الكاشف".format(setKey)
                            help += "\n⌬ {}تسجيل الدخول".format(setKey)
                            help += "\n⌬ {}تسجيل الخروج".format(setKey)
                            help += "\n⌬ {}اعادة التشغيل".format(setKey)
                            help += "\n⌬ {}اضافة".format(setKey)
                            help += "\n⌬ {}حذف".format(setKey)
                            help += "\n⌬ {}القائمة".format(setKey)
                            help += "\n⌬ {}الاسم".format(setKey)
                            help += "\n⌬ {}الصورة".format(setKey)
                            help += "\n⌬ {}طلب دخول".format(setKey)
                            help += "\n⌬ {}حذف رقم".format(setKey)
                            mentions(to, str(help),[khietag])
                        except Exception as error:
                            sendFooter(to, "「 النتيجة خطأ 」\n" + str(error))
#==========================================
                    elif cmd == "تسجيل الدخول":
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ الحساب : @!\n⌬ اكتب : {}تسجيل الحروج'.format(setKey),' ', [msg._from])
                    elif cmd == "تسجيل الخروج" and msg._from in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            noobcoder.sendMention(msg.to, '⌬ الحساب: @!\n⌬ الحاله :نجح تسجيل الخروج',' ', [msg._from])
                    elif cmd == "تسجيل الخروج" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ الحساب : @!\n⌬ اكتب : {}تسجيل الدخول'.format(setKey),' ', [msg._from])
                    elif text.lower().startswith("اضفني "):
                        if msg._from not in premium['myService']:
                            nama = str(text.split(' ')[1])
                            premium['myService'][msg._from] =  '%s' % nama
                            noobcoder.sendMention(msg.to, "「 اضفني 」 \nنجح @! سجل الدخول الان..","",[msg._from])
                        else:
                            noobcoder.sendMention(msg.to, "「اضفنس」\nOwner @!موجود بالفعل..","",[msg._from])
                    elif text.lower().startswith("addsb") and msg._from in myAdmin and to not in chatbot["botOn"]:
                        anu = msg.text.split(" ")
                        anu2 = msg.text.replace(anu[0] + " ","")
                        anu3 = anu2.split("|")
                        nama = str(anu3[0])
                        mid = str(anu3[1])
                        if mid not in premium['myService']:
                            premium['myService'][mid] =  '%s' % nama
                            noobcoder.sendMention(to, '「 Service 」\nAdd @!to service ','', [mid])
                        if mid in premium['myService']:
                            noobcoder.sendMention(to, '「 Service 」\nUser @!already in service  ','', [mid])
                    elif cmd.startswith("اضافة ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 not in premium['myService']:
                                    nama = str(text.split(' ')[1])
                                    premium['myService'][key1] =  '%s' % nama
                                    noobcoder.sendMention(msg.to, '⌬ @! تمت الاضافة الى الخدمة','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ الحساب @! موجودبالفعل','', [key1])
                    elif cmd.startswith('حذف رقم ') and msg._from in myAdmin:
                        h = [a for a in premium['myService']]
                        mid = h[int(text.lower().split(' ')[1])-1]
                        user = premium["myService"][mid]
                        if mid in premium['myService'] and mid not in premium['listLogin']:
                            del premium['myService'][mid]
                            noobcoder.sendMention(to, ' تم الحذف @! ','', [mid])
                        if mid in premium['listLogin']:
                            del premium['listLogin'][mid]
                            del premium['myService'][mid]
                            os.system("screen -S {} -X kill".format(user))
                            os.system('rm -r {}'.format(user))
                        noobcoder.sendMention(to, "الحساب @!تم حذفة.","",[mid])                        
                    elif cmd.startswith("حذف ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 in premium['myService']:
                                    del premium['myService'][key1]
                                    noobcoder.sendMention(msg.to, '⌬ @! تم الحذف','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ الحساب @! ليس موجود','', [key1])
                    elif text.lower().startswith("addsb") and msg._from in myAdmin and to not in chatbot["botOff"]:
                        anu = msg.text.split(" ")
                        anu2 = msg.text.replace(anu[0] + " ","")
                        anu3 = anu2.split("|")
                        nama = str(anu3[0])
                        mid = str(anu3[1])
                        if mid not in premium['myService']:
                            premium['myService'][mid] =  '%s' % nama
                            noobcoder.sendMention(to, '「 Service 」\nAdd @!to service ','', [mid])
                        if mid in premium['myService']:
                            noobcoder.sendMention(to, '「 Service 」\nUser @!already in service  ','', [mid])
                    elif cmd == "القائمة" and msg._from in myAdmin and to not in chatbot["botMute"]:
                        h = [a for a in premium['myService']]
                        k = len(h)//20
                        for aa in range(k+1):
                            if aa == 0:msgas = '「 قائمة العملاء 」\n';no = aa
                            else:msgas = '「 قائمة العملاء 」\n';no = aa * 20
                            for a in h[aa * 20 : (aa + 1) * 20]:
                                no+=1
                                if premium['myService'][a] == "":cd = "None."
                                else:cd = premium['myService'][a]
                                if no == len(h):msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                                else:msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                            noobcoder.sendMention(msg.to, msgas,'', h[aa * 20 : (aa+1)*20])
                    elif cmd == "اعادة تشغيل":
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                            time.sleep(3)
                            noobcoder.sendMention(msg.to, '「  اعادة تشغيل السلف 」\n> @! نجح',' ', [msg._from])
#==========================================
#==========================================
                    elif cmd.startswith("الاسم "):
                        if msg._from in myAdmin:
                            string = removeCmd("name", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 تم تغير الاسم 」\الحاله : نجاح\nمن : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("الحاله "):
                        if msg._from in myAdmin:
                            string = removeCmd("status", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 تحديث الحاله 」\nالحاله : نجاح\nمن : "+str(pname)+"\nTo :"+str(string))
                    elif text.lower() == "طلب دخول":
                        contact = noobcoder.getContact(sender)
                        owner = "ufaf5a29501b192057f071ee755429177"
                        noobcoder.sendContact(owner, "" + str(sender))
                        ayu = "طلب دخول :\nمن @!"
                        mid = noobcoder.getContact(sender)
                        mentions(owner, ayu, [sender])
                        noobcoder.sendMessage(owner, "" + str(sender))
                        noobcoder.sendMention(to, "مرحبا @!\nطلبك للدخول تم ارساله الى الاونر , الرجاء الانتظار حتى قبول الطلب","",[msg._from])
                    elif cmd.startswith("محادثة الصانع"):
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        contact = noobcoder.getContact(sender)
                        owner = "ufaf5a29501b192057f071ee755429177"
                        ayu = "Sender: @!"
                        ayu += "\nMessage: {}".format(txt)
                        mentions(owner, ayu, [sender])
                        noobcoder.sendMessage(owner, "" + str(sender))
                        noobcoder.sendMention(to, "Hi @!\nmessage has been send","",[msg._from])
                    elif cmd.startswith("pc "):
                        if msg._from in myAdmin:
                            user = removeCmd("pc", text)
                            noobcoder.sendMessage(user,"hello, the login request to the selfbot has been approved by the owner, now you can access the selfbot\n\nWanna try to login ?\n\nType : Login")
#==========================================
                    elif cmd == "ping":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "PONG ! @!","",[msg._from])
                    elif cmd == "اعادة تشيغل الهلبر":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "@! سيتم اعادة التشغيل",' ', [msg._from])
                            restartBot()
                        else:pass
                    elif cmd == "lol":
                        true = True
                        data={"type":"flex","altText":"Eric Bots","contents":{
        "contents": [
            {
                "body": {
                    "contents": [
                        {
                            "aspectMode": "cover",
                            "aspectRatio": "10:4.5",
                            "gravity": "top",
                            "offsetTop": "0px",
                            "size": "full",
                            "type": "image",
                            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "4:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.gifer.com/NTlz.gif"
                                }
                            ],
                            "cornerRadius": "15px",
                            "layout": "horizontal",
                            "offsetBottom": "3px",
                            "offsetEnd": "4px",
                            "offsetStart": "4px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "40px",
                            "offsetTop": "36px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "2px",
                            "height": "3px",
                            "layout": "vertical",
                            "offsetStart": "3px",
                            "offsetTop": "79px",
                            "position": "absolute",
                            "type": "box",
                            "width": "294px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "8px",
                            "height": "40px",
                            "layout": "vertical",
                            "offsetStart": "10px",
                            "offsetTop": "85px",
                            "position": "absolute",
                            "type": "box",
                            "width": "187px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/JC79rBH/87612-6bf98354-82d2-11e4-acf3-5cb72523fab8.jpg"
                                }
                            ],
                            "cornerRadius": "8px",
                            "height": "38px",
                            "layout": "vertical",
                            "offsetStart": "11px",
                            "offsetTop": "86px",
                            "position": "absolute",
                            "type": "box",
                            "width": "185px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://calls"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/8YfQVtr/20190427-185626.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "11px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/chat"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "41px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "http://line.me/ti/p/~patih_adhi21"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/b53ztTR/20190427-191019.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "71px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "Https://smule.com/___AdHipatiH___"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/CntKh4x/20190525-152240.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "101px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/cameraRoll/multi"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "131px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "https://youtube.com"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "161px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "3px",
                            "layout": "vertical",
                            "offsetStart": "68px",
                            "offsetTop": "18px",
                            "position": "absolute",
                            "type": "box",
                            "width": "228px"
                        },
                        {
                            "backgroundColor": "#ccff00",
                            "contents": [
                                {
                                    "color": "#000000",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u23f010:21:39",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "16px",
                            "layout": "horizontal",
                            "offsetStart": "203px",
                            "offsetTop": "88px",
                            "position": "absolute",
                            "type": "box",
                            "width": "75px"
                        },
                        {
                            "backgroundColor": "#ccff00",
                            "contents": [
                                {
                                    "color": "#000000",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83d\uddd3\ufe0f2020-01-07",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "16px",
                            "layout": "vertical",
                            "offsetStart": "203px",
                            "offsetTop": "107px",
                            "position": "absolute",
                            "type": "box",
                            "width": "75px"
                        },
                        {
                            "contents": [
                                {
                                    "align": "center",
                                    "color": "#ccffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83c\udd81\ud83c\udd74\ud83c\udd82\ud83c\udd7f\ud83c\udd7e\ud83c\udd7d\ud83c\udd83\ud83c\udd70\ud83c\udd76",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "vertical",
                            "offsetStart": "45px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box",
                            "width": "150px"
                        },
                        {
                            "contents": [
                                {
                                    "align": "center",
                                    "color": "#ccffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u2b50\u2b50\u2b50\u2b50\u2b50",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "vertical",
                            "offsetStart": "201px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box",
                            "width": "90px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "70px",
                            "layout": "vertical",
                            "offsetStart": "7px",
                            "offsetTop": "8px",
                            "position": "absolute",
                            "type": "box",
                            "width": "70px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/LNF3C7S/201803255ab79c043db8e.jpg"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "35px",
                            "layout": "vertical",
                            "offsetStart": "38px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/YRQnwQY/20191210-190324.gif"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "33px",
                            "layout": "vertical",
                            "offsetStart": "37px",
                            "offsetTop": "40px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/YRQnwQY/20191210-190324.gif"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "63px",
                            "layout": "vertical",
                            "offsetStart": "10px",
                            "offsetTop": "11px",
                            "position": "absolute",
                            "type": "box",
                            "width": "63px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=u500218bb2f290d906bc4cb3fe4c9173a&oid=8bebf371326b80eb8157ac41711be95c"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "59px",
                            "layout": "vertical",
                            "offsetStart": "12px",
                            "offsetTop": "13px",
                            "position": "absolute",
                            "type": "box",
                            "width": "59px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:4",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs.line-scdn.net/0hpl-gIWXsL0MQHgc33HxQFCxbIS5nMCkLaHxhJDYeeCBuLT8WJHk1LTQZIiE4fDsXeyxldz0ed3Ft"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "59px",
                            "layout": "vertical",
                            "offsetStart": "12px",
                            "offsetTop": "13px",
                            "position": "absolute",
                            "type": "box",
                            "width": "59px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ccff00",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83d\udebaLukesxyz",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "horizontal",
                            "offsetStart": "80px",
                            "offsetTop": "20px",
                            "position": "absolute",
                            "type": "box",
                            "width": "155px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ccff00",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u1d04\u0280\u1d07\u1d00\u1d1b\u1d0f\u0280",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "horizontal",
                            "offsetStart": "239px",
                            "offsetTop": "20px",
                            "position": "absolute",
                            "type": "box",
                            "width": "70px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ffffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u029f\u1d00\u0262\u026a s\u026a\u0299\u1d1c\u1d0b \u0274\u1d0f \u1d1b\u1d00\u0262,...\u1d18\u1d0d \u1d00\u1d0a\u1d00 \u1d0a\u026a\u0262\u1d00 \u1d18\u1d07\u0274\u1d1b\u026a\u0274\u0262",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "30px",
                            "layout": "horizontal",
                            "offsetStart": "80px",
                            "offsetTop": "40px",
                            "position": "absolute",
                            "type": "box",
                            "width": "150px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyJMHWrZewTJL4WHMo6poUqX2h5Q4q9bG5e8n1XPzjAb_N4nZM"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "38px",
                            "layout": "vertical",
                            "offsetStart": "242px",
                            "offsetTop": "38px",
                            "position": "absolute",
                            "type": "box",
                            "width": "38px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=u500218bb2f290d906bc4cb3fe4c9173a&oid=8bebf371326b80eb8157ac41711be95c"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "36px",
                            "layout": "vertical",
                            "offsetStart": "243px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "36px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.imgur.com/o6hzpkS.jpg"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "34px",
                            "layout": "vertical",
                            "offsetStart": "243px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "36px"
                        }
                    ],
                    "layout": "horizontal",
                    "paddingAll": "0px",
                    "type": "box"
                },
                "type": "bubble"
            }
        ],
        "type": "carousel"
    },
    "type": "flex"
}
                        sendTemplate(to,data)
                    elif cmd == "woy":
                        data={"type":"flex","altText":"Eric Bots","contents":{
        "contents": [
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xs",
                                    "text": "\n1. About\n2. Related\n3. Profile",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xs",
                                    "text": "\n4. Media\n5. Prank\n6. Chitchat",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            },
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "\n1. Buat pap\n2. Ganti pap\n3. Keylist",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "\n4. Addkey\n5. Contactlist\n6. Addcontact",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            },
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "1. Settings\n2. Welcoming\n3. Share on\n4. Share off\n5. Chatbot on",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "6. Chatbot off\n7. Tracking on\n8. Tracking off\n9. Antiunsend on\\off",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~h71.x"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            }
        ],
        "type": "carousel"
    },
    "type": "flex"
}
                        sendTemplate(to,data)
#==========================================
                    elif cmd == "تفعيل الدخول":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == True:
                                msgs=" 「 الدخول 」\nالدخول مفعل ♪"
                            else:
                                msgs=" 「 الدخول 」\nتم التفعيل♪"
                                settings["autoJoin"] = True
                            sendFooter(to, msgs)
                    elif cmd == "ايقاف الدخول":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == False:
                                msgs=" 「 الدخول 」\nالدخول مقفل♪"
                            else:
                                msgs=" 「 الدخول 」\nالدخول مغلق♪"
                                settings["autoJoin"] = False
                            sendFooter(to, msgs)
                    elif cmd.startswith("$"):
                        if msg._from in myAdmin:
                            kntl = removeCmd("$", text)
                            ikkeh = os.popen("{}".format(str(kntl)))
                            enaena = ikkeh.read()
                            noobcoder.sendMessage(to, "{}".format(str(enaena)))
                            ikkeh.close()
                    elif cmd == "screenlist":
                        if msg._from in myAdmin:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            sendFooter1(to, "{}".format(str(a)))
                            proses.close()
                    elif cmd.startswith("post"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            gs = noobcoder.getGroup(msg.to)
                            jmlh = int(shar[1])
                            sendFooter(to, "Waiting for share.")
                            if jmlh <= 1000:
                                for baba in range(jmlh):
                                    try:
                                        noobcoder.sendPostToTalk(to, str(shar[2]))
                                    except:
                                        pass
                                sendFooter(to, "Sucess")
                            else:
                                sendFooter(to, "Amount is wrong")
                    elif cmd.startswith("postall"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            shareall(to, shar[1])
#==========================================
#==========================================
                    elif cmd == "mentions":
                        group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                        noobcoder.datamention(to,'Mentions',nama)
#==========================================
#==========================================
                    elif cmd.startswith("cvp"):
                        if msg._from in myAdmin:
                            link = removeCmd("cvp", text)
                            contact = noobcoder.getContact(sender)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = noobcoder.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")                            
#==========================================
#==========================================
                    elif cmd == "debug":
                       if msg._from in myAdmin:
                            noobcoder.sendMessage(to, debug())
                    elif cmd == "السرعة":
                        start = time.time()
                        noobcoder.sendMessage("u2cf74acf6ed04d122def4db8ffdd2e39", '</>')
                        elapsed_time = time.time() - start
                        noobcoder.sendMessage(to,"الوقت:\n%s"%str(round(elapsed_time,5)))
#==========================================
#==========================================
                    elif cmd == "المجموعات":
                       if msg._from in myAdmin:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nالعدد {} المجموعات\n\n「".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} | {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                    elif cmd.startswith('glist'):
                        if msg._from in myAdmin:
                            to = msg.to
                            gid = noobcoder.getGroupIdsJoined()
                            group = noobcoder.getGroup(gid[int(cmd.split(' ')[1])-1])
                            nama = [a.mid for a in group.members]
                            if len(cmd.split(" ")) == 2:
                                total = "Local ID: {}".format(int(cmd.split(' ')[1]))
                                noobcoder.datamention(to,'List Member',nama,'\n├Group: '+group.name[:20]+'\n├'+total)
                            if len(cmd.split(" ")) == 4:
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' mem '):noobcoder.getinformation(to,nama[int(cmd.split(' ')[3])-1],wait)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' tag'):noobcoder.adityaarchi(wait,'Mention','tag',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' kick'):noobcoder.adityaarchi(wait,'Kick Member','kick',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                    if cmd.startswith("leave groups "):
                        if msg.toType in [0,1,2]:
                            gid = noobcoder.getGroupIdsJoined()
                            if len(cmd.split(" ")) == 3:
                                selection = MySplit(cmd.split(' ')[2],range(1,len(gid)+1))
                                k = len(gid)//100
                                for a in range(k+1):
                                    if a == 0:eto='╭「 Leave Group 」─'
                                    else:eto='├「 Leave Group 」─'
                                    text = ''
                                    no = 0
                                    for i in selection.parse()[a*100 : (a+1)*100]:
                                        noobcoder.leaveGroup(gid[i - 1])
                                        no+=1
                                        if no == len(selection.parse()):text+= "\n╰{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                        else:text+= "\n│{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                    noobcoder.sendMessage(to,eto+text)
                    elif cmd.startswith("gcast "):
                      if msg._from in myAdmin:
                            txt = removeCmd("gcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter(group, "「 Group Broadcast 」\n{}".format(str(txt)))
                                time.sleep(1)
                            sendFooter(to, "Succes broadcast to {} group".format(str(len(groups))))
                    elif cmd.startswith('joinme '):
                         if msg._from in myAdmin:
                             text = msg.text.split()
                             number = text[1]
                             if number.isdigit():
                              groups = noobcoder.getGroupIdsJoined()
                              if int(number) < len(groups) and int(number) >= 0:
                                  groupid = groups[int(number)]
                                  group = noobcoder.getGroup(groupid)
                                  target = sender
                                  try:
                                      noobcoder.getGroup(groupid)
                                      noobcoder.findAndAddContactsByMid(target)
                                      noobcoder.inviteIntoGroup(groupid, [target])
                                      noobcoder.sendMessage(msg.to,"Succes invite to " + str(group.name))
                                  except:
                                      noobcoder.sendMessage(msg.to,"I no there baby")

                    elif cmd.startswith('invme '):
                         if msg._from in myAdmin:
                             cond = cmd.split(" ")
                             num = int(cond[1])
                             gid = noobcoder.getGroupIdsJoined()
                             group = noobcoder.getCompactGroup(gid[num-1])
                             noobcoder.findAndAddContactsByMid(sender)
                             noobcoder.inviteIntoGroup(gid[num-1],[sender])

                    elif cmd.startswith("openqr "):
                      if msg._from in myAdmin:
                            number = removeCmd("openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                sendFooter(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "/byeall":
                        if msg._from in myAdmin:
                            anu = noobcoder.getGroupIdsJoined()
                            for i in anu:
                                try:
                                    noobcoder.leaveGroup(i)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to, e)
                        else:noobcoder.sendMention(msg.to, "Lo siapa sih @!NGENTOT!!!","SIKONTOL",' ', [msg._from])
                    elif cmd == "hmm":
                        if msg._from in myAdmin:
                            helppss(to)
                    if text.lower() == "rname":
                        if msg._from in myAdmin:
                            key = settings["keyCommand"]
                            if settings["setKey"] == True:
                                statuskey = "Enabled"
                            else:
                                statuskey = "Disabled"
                            sendFooter(to, "⌬ Rname : "+str(key.title())+"\n⌬ Status : "+str(statuskey))
                    if text.lower() == "rname on":
                        if msg._from in myAdmin:
                            settings["setKey"] = True
                            sendFooter(to, "Rname has been enabled")
                    if text.lower() == "rname off":
                        if msg._from in myAdmin:
                            settings["setKey"] = False
                            sendFooter(to, "Rname has been disabled")
                    if text.lower().startswith("scoutflex "):
                        if msg._from in myAdmin:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = [] 
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            if lists != []:
                              for x in lists:
                                appendSteals(x)
                              noobcoder.sendMessage(to, "Done.. Now u can waiting target send flex message!")
                    if text.lower() == "clearflex":
                        if msg._from in myAdmin:
                          clearSteals()
                          noobcoder.sendMessage(to, "Data steal flex message is cleared now & set to off.")
#==========================================
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    pesan = tailah["siderPesan"]
                    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(contact.displayName),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesan),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
                
            if op.param1 in read["readPoint"]:
                _name = noobcoder.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
#==========================================
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
    
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()