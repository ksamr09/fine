# HELPER
# KHIE WAS HERE
# </> NOOB CODER 2K17
from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from KhieBots.thrift.protocol import TCompactProtocol
from KhieBots.thrift.transport import THttpClient
from KhieBots.ttypes import LoginRequest
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from threading import Thread, activeCount
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
noobcoder = LINE("u7b6bef9c26796036f95ec7057a631644:aWF0OiAxNTc5NjAwNDQ2MjA5Cg==..eUt79s8o1M70IuDdOqDhLdQTDzw=",appName="IOS\t8.16.2\tIphone X\t8.1.0")
Channel(noobcoder, "1643727178").getChannelResult().channelAccessToken
#=======================================================
waitOpen = codecs.open("noobcoder/wait.json","r","utf-8")
settingsOpen = codecs.open("noobcoder/temp.json","r","utf-8")
premiumOpen = codecs.open("noobcoder/user.json","r","utf-8")
javaOpen = codecs.open("noobcoder/java.json","r","utf-8")
#=====================================================================
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
loop = asyncio.get_event_loop()
myAdmin = ["u5ae4ebb8ddc570dd80c70c0710248a22","u6e882277271440a7c2e8a2a0a5c38cef","u8fa89bf1904f29fa576993a99320f298"]
botStart = time.time()
msg_dict = {}
temp_flood = {}
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
premium = json.load(premiumOpen)
java = json.load(javaOpen)

hoho = {
    "savefile": False,
    "namefile": "",
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = { 
    "readMember": {},
    "readPoint": {}
}

wmin = {
    "wMessage": False,
    "textnya": "Enjoying in this group",
}

lvin = {
    "lMessage": False,
    "textnya": "See u next time",
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

setbot = {
    "background": "#000000",
    "text": "#ffffff",
    "separator": "#ffffff"
}

gwcool = {
    "squad": "NOOB CODER™",
}
#=====================================================================
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
#=====================================================================
with open("noobcoder/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("noobcoder/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "NOOB CODER™",
            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u708242457e625a5ef306804d8c0b0ac5').pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=u708242457e625a5ef306804d8c0b0ac5"
        }
    }
    sendTemplate(to, data)
def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def foro(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "styles": {
    "footer": {
    "backgroundColor": "{}".format(setbot["background"])
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
     "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    {
    "type": "text",
    "text": text,
    "color": "{}".format(setbot["text"]),
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "md"
    },
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)
def helpss(to):
    ret_ = helpers(to)
    k = len(ret_)//10
    for aa in range(k+1):
        data = {
            "type": "flex",
            "altText": "Help",
            "contents": {
                "type": "carousel",
                "contents": ret_[aa*10 : (aa+1)*10]
            }
        }
        sendTemplate(to, data)
def helpers(to):
    ret_ = []
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Login%20sb"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Restart%20sb"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout%20sb"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Login sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Restart sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Logout sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reader"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Support"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mentions"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Reader',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Support',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Mentions',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    return ret_
def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def powpow():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def getmytoken():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def shareall(to, text):
    lol = noobcoder.getGroupIdsJoined()
    for group in lol:
        noobcoder.sendPostToTalk(group, text)
    noobcoder.sendMessage(to, "Share in {} group".format(str(len(lol))))
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
#def Template(to):
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)

def B64e(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64encode(url.encode()).decode())

def B64d(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64decode(url.encode()).decode())
	
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("noobcoderWasHere.mp4")
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
        
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("noobcoder/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('noobcoder/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('noobcoder/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('noobcoder/user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = java
        f = codecs.open('noobcoder/java.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
                        
        if op.type in [22,24]:
            client.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
        if op.type == 15:
            print ("[ 15 ] NOTIFIED LEAVE GROUP")
            if lvin["lMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = lvin["textnya"]
                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Bye bye {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 17:
            print ("[ 17 ] NOTIFIED INVITE INTO GROUP")
            if wmin["wMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = wmin["textnya"]
                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "Welcome to {}".format(str(fit.name)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 19:
                    khie = noobcoder.getContact(op.param2)
                    ayu = noobcoder.getContact(op.param3)
                    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "#ffffff",
    "contents": [
      {
        "type": "text",
        "text": "KICK NOTIFY",
        "weight": "bold",
        "size": "xxl",
        "margin": "md"
      },
      {
        "type": "separator",
        "color": "#000000"
      },
      {
        "type": "text",
        "text": "Execution :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(khie.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param2).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      },
      {
        "type": "text",
        "text": "Victim :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(ayu.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param3).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            khietag = "u708242457e625a5ef306804d8c0b0ac5"
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        noobcoder.sendMessage(to, str(e))
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             noobcoder.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        sendFooter(to,"Profile Image Updated.")
                if msg.contentType == 1: 
                    if settings["changeCoverProfile"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        noobcoder.updateProfileCover(path)
                        sendFooter(to,"Cover Image Updated.")                                           
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
                    if msg._from in myAdmin:
                        if "/remote" in cmd:
                            function = lambda s:s[:1].lower() + s[1:] if s else ''
                            number = cmd.split("/remote:")[1];number = number.split()[0];noobcoder.getGroupIdsJoined()
                            if number.isdigit():number = int(number);group = noobcoder.getGroupIdsJoined()[number-1];to = group
                            cmd = cmd.replace("/remote:%s"%number,"").lstrip().rstrip()
                            if '/remote:' in text:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            else:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            if msg.toType == 0:msg.to = sender
                            elif msg.toType == 2:msg.to = msg.to
                            sendFooter(msg.to, "Command '%s' has been send to : %s" % (cmd, noobcoder.getGroup(group).name))
#==========================================
                    if cmd == "threads":
                        noobcoder.sendMessage(to,'Threads: {}'.format(threading.active_count()))
                        log.info("Debug Threads.")                            
#==========================================
                    elif cmd.startswith("savefile"):
                        if msg._from in myAdmin:
                            text = removeCmd("savefile", text)
                            sep = text.split(" ")
                            key = text.replace(sep[0] + " ", text)
                            if " " in key:
                                noobcoder.sendMessage(to, "Failed !")
                            else:
                                hoho["namafile"] = str(key).lower()
                                hoho["savefile"] = True
                                noobcoder.sendMessage(to, "Send file to save to be「 {} 」".format(str(key).lower()))
                    elif cmd.startswith("exec"):
                        if msg._from in myAdmin:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
#==========================================
                    elif cmd.startswith("down "):
                        if msg._from in myAdmin:
                           number = removeCmd("down", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 5000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 5000.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please specify a valid number.")
                    elif cmd == "change dp" :
                        if msg._from in myAdmin:
                            settings["changePicture"] = True
                            sendFooter(to, "Send a Image to change picture.")
                    elif cmd == "change cover":
                        if msg._from in myAdmin:
                            settings["changeCoverProfile"] = True
                            sendFooter(to,"Send a Image to change cover.")
                    elif cmd == "read on":
                        tailah["siderTemp"][receiver] = []
                        sendFooter(to, "Getreader set to on.")
                    elif cmd == "read off":
                        if receiver in tailah["siderTemp"]:
                            del tailah["siderTemp"][receiver]
                            sendFooter(to, "Getreader set to off.")
                    elif cmd == "welcome on":
                        if wmin["wMessage"] == True:
                            msgs=" 「 Welcome 」\nWelcomemsg already Enable♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to Enable♪"
                            wmin["wMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "welcome off":
                        if wmin["wMessage"] == False:
                            msgs=" 「 wMessage 」\nWelcomemsg already DISABLED♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to DISABLED♪"
                            wmin["wMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd == "leave on":
                        if lvin["lMessage"] == True:
                            msgs=" 「 Leave 」\nLeavemsg already Enable♪"
                        else:
                            msgs=" 「 Leave 」\nLeavemsg set to Enable♪"
                            lvin["lMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "leave off":
                        if lvin["lMessage"] == False:
                            msgs=" 「  Leave 」\nLeavemsg already DISABLED♪"
                        else:
                            msgs=" 「  Leave  」\nLeavemsg set to DISABLED♪"
                            lvin["lMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd.startswith("updatername "):
                        if msg._from in myAdmin:
                            key = removeCmd("updatername", text)
                            kiy = settings["keyCommand"]
                            settings["keyCommand"] = str(key).lower()
                            sendFooter(to, "╭──「 Update Rname 」\n│ ⌬ Status : Success\n│ ⌬ From : "+str(kiy.title())+"\n╰To : "+str(key.title()))
#==========================================
                    if cmd == "kiss me":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+noobcoder.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")
                    elif cmd == "reader":
                        ret = "Now set : " + str(tailah["siderPesan"])
                        ret += "\n\n⌬ {}read on/off".format(setKey)
                        ret += "\n⌬ {}read set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "leave":
                        ret = "Now set : " + str(lvin["textnya"])
                        ret += "\n\n⌬ {}leave on/off".format(setKey)
                        ret += "\n⌬ {}leave set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "welcome":
                        ret = "Now set : " + str(wmin["textnya"])
                        ret += "\n\n⌬ {}welcome on/off".format(setKey)
                        ret += "\n⌬ {}welcome set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "invitependings":
                        if msg._from in myAdmin:
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    noobcoder.sendMessage(msg.to, "No invites Pending")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        noobcoder.cancelGroupInvitation(to, [inv])
                                        noobcoder.findAndAddContactsByMid(inv)                                        
                                        noobcoder.inviteIntoGroup(to, [inv])
#==========================================
                    elif cmd.startswith("read set "):
                        text_ = removeCmd("read set", text)
                        try:
                            tailah["siderPesan"] = text_
                            sendFooter(to,"「 Get Reader 」\nChanged to : " + text_)
                        except:
                            foto(to,"「Get Reader 」\nFailed to replace message")
                    elif cmd.startswith("leave set "):
                        text_ = removeCmd("leave set", text)
                        try:
                            lvin["textnya"] = text_
                            sendFooter(to,"「 LeaveMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 LeaveMsg 」\nFailed to replace message")
                    elif cmd.startswith("welcome set "):
                        text_ = removeCmd("welcome set", text)
                        try:
                            wmin["textnya"] = text_
                            sendFooter(to,"「 WelcomeMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 WelcomeMsg 」\nFailed to replace message")
                    elif cmd.startswith("bye "):
                        if msg._from in myAdmin:
                            number = removeCmd("bye", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                noobcoder.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "support":
                        support(to)
                    elif cmd == "login" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                 def frzky():
                                     a = powpow()
                                     a.update({'x-lpqs' : '/api/v4/TalkService.do'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     qr = client.getAuthQrcode(keepLoggedIn=1, systemName='noobcoderBot-PC')
                                     link = "line://au/q/" + qr.verifier
                    #              noobcoder.sendMention(to, 'Click link @!, only 2 minutes\n{}'.format(link),"",[msg._from])
                                     contact = noobcoder.getContact(sender)
                                     LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                                     data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "CLICK HERE FOR LOGIN",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                            "action": {
                                "type": "uri",
                                "uri": "{}".format(link)
                            }
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                     sendTemplate(to, data)
                                     a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                     json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=a).text)
                                     a.update({'x-lpqs' : '/api/v4p/rs'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     req = LoginRequest()
                                     req.type = 1
                                     req.verifier = qr.verifier
                                     req.e2eeVersion = 1
                                     res = client.loginZ(req)
                                     if msg._from not in premium['listLogin']:
                                         premium['listLogin'][msg._from] =  '%s' % user
                                         isi = "{}".format(res.authToken)
                                         os.system('cp -r Ak13 {}'.format(user))
                                         os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                         os.system('screen -dmS {}'.format(user))
                                         os.system('screen -r {} -X Ak13 "cd {} && python3 Ak13.py \n"'.format(user, user))
                                         data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "File : {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "SUCESS TO LOGIN",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                         sendTemplate(to, data)
                                     else:
                                         noobcoder.sendMention(msg.to, '「 Req Login 」\n• Status : Failed\n• User: @!',' ', [msg._from])
                                 thread = threading.Thread(target=frzky)
                                 thread.daemon = True
                                 thread.start()
                            except:
                                 noobcoder.sendMention(msg.to, '「 Reg Login 」\n• Status : Failed\n •User: @!',' ', [msg._from])
                    elif cmd == "help":
                        try:
                            help = "General Commands :\n"
                            help += "\n⌬ {}reader".format(setKey)
                            help += "\n⌬ {}mentions".format(setKey)
                            help += "\n⌬ {}addme <nama>".format(setKey)
                            help += "\n⌬ {}login".format(setKey)
                            help += "\n⌬ {}logout".format(setKey)
                            help += "\n⌬ {}restart".format(setKey)
                            help += "\n\nAuthor : @!                  "
                            mentions(to, str(help),[khietag])
                        except Exception as error:
                            sendFooter(to, "「 Result Error 」\n" + str(error))
#==========================================
                    elif cmd == "login":
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ User : @!\n⌬ Type : {}logout'.format(setKey),' ', [msg._from])
                    elif cmd == "logout" and msg._from in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            noobcoder.sendMention(msg.to, '⌬ User: @!\n⌬ Stats : Success to logout',' ', [msg._from])
                    elif cmd == "logout" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ User : @!\n⌬ Type : {}login'.format(setKey),' ', [msg._from])
                    elif text.lower().startswith("addme "):
                        if msg._from not in premium['myService']:
                            nama = str(text.split(' ')[1])
                            premium['myService'][msg._from] =  '%s' % nama
                            noobcoder.sendMention(msg.to, "「 Add Me 」 \nAdd @! to Login..","",[msg._from])
                        else:
                            noobcoder.sendMention(msg.to, "「Add Me 」\nOwner @! already in List..","",[msg._from])
                    elif cmd.startswith("addservice ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 not in premium['myService']:
                                    nama = str(text.split(' ')[1])
                                    premium['myService'][key1] =  '%s' % nama
                                    noobcoder.sendMention(msg.to, '⌬ Added @! to service','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ User @! already in service','', [key1])
                    elif cmd.startswith('delnumber ') and msg._from in myAdmin:
                        h = [a for a in premium['myService']]
                        mid = h[int(text.lower().split(' ')[1])-1]
                        user = premium["myService"][mid]
                        if mid in premium['myService'] and mid not in premium['listLogin']:
                            del premium['myService'][mid]
                            noobcoder.sendMention(to, ' Service Delete @!in service ','', [mid])
                        if mid in premium['listLogin']:
                            del premium['listLogin'][mid]
                            del premium['myService'][mid]
                            os.system("screen -S {} -X kill".format(user))
                            os.system('rm -r {}'.format(user))
                        noobcoder.sendMention(to, "User @!has been deleted.","",[mid])                        
                    elif cmd.startswith("delservice ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 in premium['myService']:
                                    del premium['myService'][key1]
                                    noobcoder.sendMention(msg.to, '⌬ Deleted @! from service','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ User @! not in service','', [key1])
                    elif cmd == "list service" and msg._from in myAdmin and to not in chatbot["botMute"]:
                        h = [a for a in premium['myService']]
                        k = len(h)//20
                        for aa in range(k+1):
                            if aa == 0:msgas = '「 List Service 」\n';no = aa
                            else:msgas = '「 List Service 」\n';no = aa * 20
                            for a in h[aa * 20 : (aa + 1) * 20]:
                                no+=1
                                if premium['myService'][a] == "":cd = "None."
                                else:cd = premium['myService'][a]
                                if no == len(h):msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                                else:msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                            noobcoder.sendMention(msg.to, msgas,'', h[aa * 20 : (aa+1)*20])
                    elif cmd == "restart":
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                            time.sleep(3)
                            noobcoder.sendMention(msg.to, '「  Restart Sb  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
#==========================================
                    elif cmd.startswith("name "):
                        if msg._from in myAdmin:
                            string = removeCmd("name", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("status "):
                        if msg._from in myAdmin:
                            string = removeCmd("status", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
#==========================================
                    elif cmd == "ping":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "PONG ! @!","",[msg._from])
                    elif cmd == "reboot":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "@! Brb , going to pee",' ', [msg._from])
                            restartBot()
                        else:pass
#==========================================
                    elif cmd == "join on":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == True:
                                msgs=" 「 Join 」\nJoin already Enable♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to Enable♪"
                                settings["autoJoin"] = True
                            sendFooter(to, msgs)
                    elif cmd == "join off":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == False:
                                msgs=" 「 Join 」\nJoin already DISABLED♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                settings["autoJoin"] = False
                            sendFooter(to, msgs)
                    elif cmd.startswith("$"):
                        if msg._from in myAdmin:
                            kntl = removeCmd("$", text)
                            ikkeh = os.popen("{}".format(str(kntl)))
                            enaena = ikkeh.read()
                            noobcoder.sendMessage(to, "{}".format(str(enaena)))
                            ikkeh.close()
                    elif cmd == "screenlist":
                        if msg._from in myAdmin:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            sendFooter1(to, "{}".format(str(a)))
                            proses.close()
                    elif cmd.startswith("post"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            gs = noobcoder.getGroup(msg.to)
                            jmlh = int(shar[1])
                            sendFooter(to, "Waiting for share.")
                            if jmlh <= 1000:
                                for baba in range(jmlh):
                                    try:
                                        noobcoder.sendPostToTalk(to, str(shar[2]))
                                    except:
                                        pass
                                sendFooter(to, "Sucess")
                            else:
                                sendFooter(to, "Amount is wrong")
                    elif cmd.startswith("postall"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            shareall(to, shar[1])
#==========================================
#==========================================
                    elif cmd == "mentions":
                        group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                        noobcoder.datamention(to,'Mentions',nama)
#==========================================
#==========================================
                    elif cmd.startswith("cvp"):
                        if msg._from in myAdmin:
                            link = removeCmd("cvp", text)
                            contact = noobcoder.getContact(sender)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = noobcoder.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")                            
#==========================================
#==========================================
                    elif cmd == "debug":
                       if msg._from in myAdmin:
                            noobcoder.sendMessage(to, debug())
                    elif cmd == "speed":
                        start = time.time()
                        noobcoder.sendMessage("u2cf74acf6ed04d122def4db8ffdd2e39", '</>')
                        elapsed_time = time.time() - start
                        noobcoder.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
#==========================================
#==========================================
                    elif cmd == "glist":
                       if msg._from in myAdmin:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n\n「 Command 」\n\n> Remote Mention\nUsage: #Glist [num] tag [1|<|>|-]\n\n> Remote Kick\nUsage: #glist [num] kick [1|<|>|-]\n\n> Leave Groups\nUsage: #Leave [num]\n\n> Get QR\nUsage: #Openqr  [num]\n\n> Cek Member\nUsage: #Glist [num]\nUsage: #Glist [num] mem [num]".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} | {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                    elif cmd.startswith('glist'):
                        if msg._from in myAdmin:
                            to = msg.to
                            gid = noobcoder.getGroupIdsJoined()
                            group = noobcoder.getGroup(gid[int(cmd.split(' ')[1])-1])
                            nama = [a.mid for a in group.members]
                            if len(cmd.split(" ")) == 2:
                                total = "Local ID: {}".format(int(cmd.split(' ')[1]))
                                noobcoder.datamention(to,'List Member',nama,'\n├Group: '+group.name[:20]+'\n├'+total)
                            if len(cmd.split(" ")) == 4:
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' mem '):noobcoder.getinformation(to,nama[int(cmd.split(' ')[3])-1],wait)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' tag'):noobcoder.adityaarchi(wait,'Mention','tag',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' kick'):noobcoder.adityaarchi(wait,'Kick Member','kick',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                    if cmd.startswith("leave groups "):
                        if msg.toType in [0,1,2]:
                            gid = noobcoder.getGroupIdsJoined()
                            if len(cmd.split(" ")) == 3:
                                selection = MySplit(cmd.split(' ')[2],range(1,len(gid)+1))
                                k = len(gid)//100
                                for a in range(k+1):
                                    if a == 0:eto='╭「 Leave Group 」─'
                                    else:eto='├「 Leave Group 」─'
                                    text = ''
                                    no = 0
                                    for i in selection.parse()[a*100 : (a+1)*100]:
                                        noobcoder.leaveGroup(gid[i - 1])
                                        no+=1
                                        if no == len(selection.parse()):text+= "\n╰{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                        else:text+= "\n│{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                    noobcoder.sendMessage(to,eto+text)
                    elif cmd.startswith("gcast "):
                      if msg._from in myAdmin:
                            txt = removeCmd("gcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter(group, "「 Group Broadcast 」\n{}".format(str(txt)))
                                time.sleep(1)
                            sendFooter(to, "Succes broadcast to {} group".format(str(len(groups))))
                    elif cmd.startswith('joinme '):
                         if msg._from in myAdmin:
                             text = msg.text.split()
                             number = text[1]
                             if number.isdigit():
                              groups = noobcoder.getGroupIdsJoined()
                              if int(number) < len(groups) and int(number) >= 0:
                                  groupid = groups[int(number)]
                                  group = noobcoder.getGroup(groupid)
                                  target = sender
                                  try:
                                      noobcoder.getGroup(groupid)
                                      noobcoder.findAndAddContactsByMid(target)
                                      noobcoder.inviteIntoGroup(groupid, [target])
                                      noobcoder.sendMessage(msg.to,"Succes invite to " + str(group.name))
                                  except:
                                      noobcoder.sendMessage(msg.to,"I no there baby")

                    elif cmd.startswith('invme '):
                         if msg._from in myAdmin:
                             cond = cmd.split(" ")
                             num = int(cond[1])
                             gid = noobcoder.getGroupIdsJoined()
                             group = noobcoder.getCompactGroup(gid[num-1])
                             noobcoder.findAndAddContactsByMid(sender)
                             noobcoder.inviteIntoGroup(gid[num-1],[sender])

                    elif cmd.startswith("openqr "):
                      if msg._from in myAdmin:
                            number = removeCmd("/openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                sendFooter(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "/byeall":
                        if msg._from in myAdmin:
                            anu = noobcoder.getGroupIdsJoined()
                            for i in anu:
                                try:
                                    noobcoder.leaveGroup(i)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to, e)
                        else:noobcoder.sendMention(msg.to, "Lo siapa sih @!NGENTOT!!!","SIKONTOL",' ', [msg._from])
                    if text.lower() == "rname":
                        if msg._from in myAdmin:
                            key = settings["keyCommand"]
                            if settings["setKey"] == True:
                                statuskey = "Enabled"
                            else:
                                statuskey = "Disabled"
                            sendFooter(to, "⌬ Rname : "+str(key.title())+"\n⌬ Status : "+str(statuskey))
                    if text.lower() == "rname on":
                        if msg._from in myAdmin:
                            settings["setKey"] = True
                            sendFooter(to, "Rname has been enabled")
                    if text.lower() == "rname off":
                        if msg._from in myAdmin:
                            settings["setKey"] = False
                            sendFooter(to, "Rname has been disabled")
#==========================================
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    pesan = tailah["siderPesan"]
                    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(contact.displayName),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesan),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
                
            if op.param1 in read["readPoint"]:
                _name = noobcoder.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
#==========================================
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
    
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()